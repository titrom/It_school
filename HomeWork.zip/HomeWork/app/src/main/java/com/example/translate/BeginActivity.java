package com.example.translate;

import android.app.Activity;

public class BeginActivity extends Activity {
}
