package com.example.translate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private Button begin,ok,work,about;
private Dialog dialog,dialogWork;
private RadioGroup radioGroup;
private RadioButton upp,low;
private EditText textEd;
private String string;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        begin=findViewById(R.id.begin);
        work=findViewById(R.id.work);
        about=findViewById(R.id.about);
        dialog=new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog_begin);
        dialog.setTitle("Begin");

        begin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textEd=dialog.findViewById(R.id.textEd);
                radioGroup=dialog.findViewById(R.id.radiog);
                ok=dialog.findViewById(R.id.Ok);
                dialog.show();
                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        switch (checkedId){
                            case R.id.uppercase: string=textEd.getText().toString().toUpperCase();break;
                            case R.id.lowercase: string=textEd.getText().toString().toLowerCase();break;
                            default:break;
                        }

                    }
                });
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        radioGroup.clearCheck();
                        dialog.dismiss();

                    }
                });
                dialogWork=new Dialog(MainActivity.this);
                dialogWork.setContentView(R.layout.dialog_work);
                dialogWork.setTitle("Work");
                work.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TextView working=dialogWork.findViewById(R.id.working);
                        working.setText(string);
                        dialogWork.show();

                    }
                });
            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,AboutActivity.class);
                startActivity(intent);
            }
        });






    }
}